#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Ling Jin
# Date:  Nov 19, 2018
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created script
#   LingJin, 11/19/2018, Added code to complete assignment 5
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection
# strTask = Capture the user's new task input
# strPri = the Priority of the user's new task
# dicNewRow = the new data input
# count = number of input
objFileName = "Todo.txt"
strData = ""
dicRow = {}
lstTable = []

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
#  Step 1 - Load data from a file
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
objFile = open("/Users/apple/Documents/_PythonClass /Assignment05/Todo.txt")
for lines in objFile:
    lines = lines.strip('\n')
    strData = lines.split(",")
    dicRow = {"Task":strData[0],"Priority":strData[1].strip("\n")}
    # Add the each dictionary "row" to a python list "table"
    lstTable.append(dicRow)
objFile.close()
#Display current items todo to user
print("--------The current items ToDo are:----------")
for dicRow in lstTable:
    print(dicRow["Task"]+"("+dicRow["Priority"]+")")
print("---------------------------------------------")

# Step 2
# Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

# Step 3
# Display all todo items to user
    #Show the current items in the table
    if (strChoice.strip() == '1'):
        print("--------The current items ToDo are:----------")
        for dicRow in lstTable:
            print(dicRow["Task"] + "(" + dicRow["Priority"] + ")")
        print("---------------------------------------------")
        continue

# Step 4
# Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        strTask = input("What is the Task: ")
        strPri = input("What is the priority (low/high): ")
        dicNewRow = {"Task":strTask,"Priority":strPri}
        lstTable.append(dicNewRow)

        print("--------The current items ToDo are:----------")
        for dicRow in lstTable:
            print(dicRow["Task"] + "(" + dicRow["Priority"] + ")")
        print("---------------------------------------------")
        continue

# Step 5
# Remove a new item to the list/Table
    elif (strChoice.strip() == '3'):
        count = -1 #set count = -1 so the minimum number = 0
        try:
            for rows in lstTable:
                count = count + 1  # to count number of rows
                print('\n' + str(count) + "  " + str(rows))  #Display rows for user to choose from
            intRemove = int(input("Which TASK whould you like removed? "))#Choose which row they want to delete
            del lstTable[intRemove] #Delete the row
            print("The task was removed.") #Display a information to user
        except: #Try this if user did not enter a correct number
            print("The task number can not be find.")
        # Display current items todo to user
        print("--------The current items ToDo are:----------")
        for dicRow in lstTable:
            print(dicRow["Task"] + "(" + dicRow["Priority"] + ")")
        print("---------------------------------------------")
        continue

# Step 6
# Save tasks to the ToDo.txt file
    elif (strChoice.strip() == '4'):
        objFile = open("/Users/apple/Documents/_PythonClass /Assignment05/Todo.txt","w")
        for item in lstTable:
            objFile.write(item["Task"]+"("+item["Priority"]+")"+"\n")
        objFile.close()
        # Display current items todo to user
        print("--------The data saved are:------------------")
        for dicRow in lstTable:
            print(dicRow["Task"] + "(" + dicRow["Priority"] + ")")
        print("---------------------------------------------")
        continue

# Step 7
# Exit program
    elif (strChoice == '5'):
        print("exit the program!")
        break  # and Exit the program

# -------------------------------


