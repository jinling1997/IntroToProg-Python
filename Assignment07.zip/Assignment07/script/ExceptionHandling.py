#-------------------------------------------------#
# Title: Example of Python Exception Handling
# Dev:   LingJin
# Date:  Nov 3, 2018
# ChangeLog: (Who, When, What)
#  LingJin, Nov 3,2018, Created script
#-------------------------------------------------#

## Data #############################################
objFile = None
intN1 = None # The number user enter
decValue = None #The result we get
fileName = "/Users/apple/Documents/_PythonClass /Assignment07/script/Result.txt"
## Data #############################################

## Data Processing #################################
def divisonAlg():
    '''  #make a fuction for 5/x
    :return:
    '''
    print("result = 5/x")
    intN1 = int(input("x= "))
    try:
        decValue = 5/intN1
        print("5/x="+str(decValue))
        objFile.write("5/x="+str(decValue) + "\n")
    except ZeroDivisionError as e: #To be more specific if divide by zero
        print("do not divide by zero!")
    except Exception as e:
        print("There was a unexpected error!")
        print("pythons error info: "+str(e))
#end function/method

def ReadAllFileData(File, Message = "Contents"):
    '''  Display the current result list to the user
    :return: string
    '''
    try:
        print(Message)
        File.seek(0)#Make sure that it read from the top
        print(objFile.read())
    except Exception as e:
        print("Error:", e.__str__())
#end function/method
## Data Processing #################################

## I/O ############################################
try:
    objFile = open(fileName, "r+")
    ReadAllFileData(objFile,"Here is the current result:")
    divisonAlg()
    ReadAllFileData(objFile, "Here is this result was saved")
    objFile.close()
except FileNotFoundError as e: #To be more specific if file can not be found
    print("Error:"+str(e)+"\nPlease check the file name")
except Exception as e:
    print("Python reported the following error: " + str(e))
finally: #it will always run, with or without any previously encountered exceptions.
    if (objFile != None):
        objFile.close()
    print("The program has stopped")
## I/O ############################################