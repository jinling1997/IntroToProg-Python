#-------------------------------------------------#
# Title: Example of Pickling in python
# Dev:   LingJin
# Date:  Nov 3, 2018
# ChangeLog: (Who, When, What)
#  LingJin, Nov 3,2018, Created script
#-------------------------------------------------#


## Data #############################################
fileName = "/Users/apple/Documents/_PythonClass /Assignment07/script/Todo.dat" #Not .txt
Todo = ['laudary','hw','travel']
## Data #############################################

## Data Processing #################################
#store the data with the pickle.dump method
import pickle
objFile = open(fileName, "ab")
pickle.dump(Todo, objFile)
objFile.close()

#read the data back with pickle.load method
objFile = open(fileName, "rb")
TodoTest = pickle.load(objFile)
objFile.close()
## Data Processing #################################

## I/O ############################################
#present the result whether they are the same
if(Todo == TodoTest):
    print(True)
## I/O ############################################



